"""
opn2.py — Python control layer for the Nuked-OPN2 (YM2612/YM3438) core.

Wraps core/libopn2.so via ctypes and exposes musically meaningful methods
(set_instrument, note_on, note_off, render) instead of raw register writes,
while still allowing raw register access for anyone who wants it.

Native output rate derivation (NTSC Sega Genesis):
    chip input clock  = 53,693,175 / 7   =  7,670,453.57 Hz
    internal clock     = chip clock / 6   =  1,278,408.93 Hz   (per Nuked-OPN2 docs:
                                                                 1 call to OPN2_Clock
                                                                 = 1 internal clock
                                                                 = 6 chip-input clocks)
    audio sample rate  = internal / 24    =     53,267.04 Hz   (24 operator slots:
                                                                 6 channels x 4 ops,
                                                                 round-robin pipeline)
"""

import ctypes
import os
import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_LIB_PATH = os.path.join(_HERE, "..", "core", "libopn2.so")

NTSC_CHIP_CLOCK = 53_693_175 / 7          # Hz, input clock to the YM2612
PAL_CHIP_CLOCK = 53_203_424 / 7           # Hz, PAL Mega Drive variant
NATIVE_RATE = NTSC_CHIP_CLOCK / 6 / 24    # ~53267.04 Hz, see module docstring

_NOTE_OFFSETS = {"C": -9, "C#": -8, "Db": -8, "D": -7, "D#": -6, "Eb": -6,
                 "E": -5, "F": -4, "F#": -3, "Gb": -3, "G": -2, "G#": -1,
                 "Ab": -1, "A": 0, "A#": 1, "Bb": 1, "B": 2}


def note_to_freq(note: str, octave: int) -> float:
    """'C', 4 -> 261.63 Hz (A4 = 440 Hz reference, 12-tone equal temperament)."""
    semitones = _NOTE_OFFSETS[note] + (octave - 4) * 12
    return 440.0 * (2.0 ** (semitones / 12.0))


def freq_to_fnum_block(freq: float, clock: float = NTSC_CHIP_CLOCK):
    """Pick a block (0-7) that keeps fnum in the valid 11-bit range and
    return (fnum, block)."""
    best = None
    for block in range(8):
        fnum = round(freq * (2 ** (20 - block)) * 144 / clock)
        if 0 <= fnum <= 2047:
            # Prefer the block that puts fnum comfortably mid-range —
            # gives headroom for pitch bends/vibrato in either direction.
            score = abs(fnum - 1024)
            if best is None or score < best[0]:
                best = (score, fnum, block)
    if best is None:
        raise ValueError(f"frequency {freq} Hz out of representable range")
    return best[1], best[2]


class _Lib:
    """Lazily-loaded, correctly-typed ctypes handle to libopn2.so."""
    _lib = None

    @classmethod
    def get(cls):
        if cls._lib is None:
            lib = ctypes.CDLL(_LIB_PATH)
            lib.opn2_new.restype = ctypes.c_void_p
            lib.opn2_new.argtypes = []
            lib.opn2_free.argtypes = [ctypes.c_void_p]
            lib.opn2_reset.argtypes = [ctypes.c_void_p]
            lib.opn2_write.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_ubyte]
            lib.opn2_render.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                         ctypes.POINTER(ctypes.c_short)]
            cls._lib = lib
        return cls._lib


class Operator:
    """One FM operator's parameters (there are 4 per channel).

    detune: 0-7 (3-bit DT1, 4 = no detune)
    multiple: 0-15 (frequency multiplier, 0 means x0.5)
    total_level: 0 (loudest) - 127 (silent)
    attack_rate, decay_rate, sustain_rate, release_rate: 0-31 (rate) /
        release_rate is stored as 4-bit (0-15) per hardware
    sustain_level: 0 (highest) - 15 (lowest, i.e. deepest decay target)
    ssg_eg: 0 or 8-15, SSG-EG envelope mode (0 = normal ADSR, off)
    """
    __slots__ = ("detune", "multiple", "total_level", "attack_rate",
                 "decay_rate", "sustain_rate", "release_rate",
                 "sustain_level", "ssg_eg", "rate_scaling", "am_enable")

    def __init__(self, detune=0, multiple=1, total_level=20, attack_rate=31,
                 decay_rate=5, sustain_rate=0, release_rate=7,
                 sustain_level=2, ssg_eg=0, rate_scaling=0, am_enable=0):
        self.detune = detune
        self.multiple = multiple
        self.total_level = total_level
        self.attack_rate = attack_rate
        self.decay_rate = decay_rate
        self.sustain_rate = sustain_rate
        self.release_rate = release_rate
        self.sustain_level = sustain_level
        self.ssg_eg = ssg_eg
        self.rate_scaling = rate_scaling
        self.am_enable = am_enable


class FMInstrument:
    """A full 4-operator YM2612 patch: algorithm + feedback + 4 Operators."""
    __slots__ = ("algorithm", "feedback", "operators")

    def __init__(self, algorithm: int, feedback: int, operators):
        assert 0 <= algorithm <= 7
        assert 0 <= feedback <= 7
        assert len(operators) == 4
        self.algorithm = algorithm
        self.feedback = feedback
        self.operators = operators


class YM2612:
    """One emulated YM2612, 6 FM channels (0-5)."""

    _OP_OFFSETS = (0x00, 0x04, 0x08, 0x0C)  # op1..op4 register offsets

    def __init__(self):
        self._lib = _Lib.get()
        self._chip = self._lib.opn2_new()
        self._channel_instrument = [None] * 6

    def close(self):
        if self._chip:
            self._lib.opn2_free(self._chip)
            self._chip = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    # -- raw register access -------------------------------------------------
    def _port_addr_for(self, channel: int):
        # channels 0-2 live on bank A (ports 0/1), 3-5 on bank B (ports 2/3)
        if channel < 3:
            return 0, 1, channel
        return 2, 3, channel - 3

    def write(self, port: int, addr: int, data: int):
        self._lib.opn2_write(self._chip, port, addr & 0xFF)
        self._lib.opn2_write(self._chip, port + 1, data & 0xFF)

    # -- instrument / voice ----------------------------------------------------
    def set_instrument(self, channel: int, instrument: FMInstrument):
        addr_port, data_port, ch = self._port_addr_for(channel)
        for op, off in zip(instrument.operators, self._OP_OFFSETS):
            base = 0x30 + off + ch
            self.write(addr_port, base, ((op.detune & 0x7) << 4) | (op.multiple & 0xF))
            self.write(addr_port, base + 0x10, op.total_level & 0x7F)
            self.write(addr_port, base + 0x20, ((op.rate_scaling & 0x3) << 6) | (op.attack_rate & 0x1F))
            self.write(addr_port, base + 0x30, ((op.am_enable & 0x1) << 7) | (op.decay_rate & 0x1F))
            self.write(addr_port, base + 0x40, op.sustain_rate & 0x1F)
            self.write(addr_port, base + 0x50, ((op.sustain_level & 0xF) << 4) | (op.release_rate & 0xF))
            self.write(addr_port, base + 0x60, op.ssg_eg & 0xF)
        self.write(addr_port, 0xB0 + ch, ((instrument.feedback & 0x7) << 3) | (instrument.algorithm & 0x7))
        self.write(addr_port, 0xB4 + ch, 0xC0)  # pan L+R on, AMS/PMS off
        self._channel_instrument[channel] = instrument

    def set_lfo(self, enable: bool, freq: int = 0):
        self.write(0, 0x22, (0x08 if enable else 0x00) | (freq & 0x7))

    def note_on(self, channel: int, note: str, octave: int, clock: float = NTSC_CHIP_CLOCK):
        freq = note_to_freq(note, octave)
        fnum, block = freq_to_fnum_block(freq, clock)
        addr_port, data_port, ch = self._port_addr_for(channel)
        self.write(addr_port, 0xA4 + ch, ((block & 0x7) << 3) | (fnum >> 8))
        self.write(addr_port, 0xA0 + ch, fnum & 0xFF)
        key_code = channel if channel < 3 else channel + 1  # 0,1,2,4,5,6
        self.write(0, 0x28, 0xF0 | key_code)

    def note_off(self, channel: int):
        key_code = channel if channel < 3 else channel + 1
        self.write(0, 0x28, 0x00 | key_code)

    # -- rendering -------------------------------------------------------------
    def render(self, n_samples: int) -> np.ndarray:
        """Render n_samples of native-rate (~53267 Hz) stereo audio.
        Returns a float32 array shaped (n_samples, 2) in range [-1, 1]."""
        buf = (ctypes.c_short * (n_samples * 2))()
        self._lib.opn2_render(self._chip, n_samples, buf)
        arr = np.frombuffer(buf, dtype=np.int16).astype(np.float32) / 32768.0
        return arr.reshape(-1, 2)
