"""
events.py — the event vocabulary a generative model (any architecture:
transformer, RNN, genetic/rule-based, RL agent...) outputs to drive both
chips. This is the "DefleMask for neural networks" surface: a network
never has to touch FM operator physics directly, just this flat,
tokenizable event stream.

Design goals:
  - Flat sequence, self-timed via Wait events (tracker-style delta-time)
  - Every event is a plain dataclass -> trivial to_dict()/from_dict() for
    JSON, one-hot encoding, or any other model I/O convention
  - Instruments referenced by name (see instruments.BANK) rather than raw
    operator parameters, mirroring a DefleMask instrument bank

A model's job is reduced to: "which event type, which channel, which
note/instrument, how long to wait" — a small, fixed vocabulary well
suited to autoregressive token generation.
"""

from dataclasses import dataclass, asdict
from typing import List, Dict, Any


class Event:
    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["type"] = self.__class__.__name__
        return d

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Event":
        cls = _EVENT_TYPES[d["type"]]
        kwargs = {k: v for k, v in d.items() if k != "type"}
        return cls(**kwargs)


@dataclass
class Wait(Event):
    """Advance the sequence clock by `ticks` ticks."""
    ticks: int


@dataclass
class FMInstrumentSelect(Event):
    """Assign a preset instrument (see instruments.BANK) to an FM channel (0-5)."""
    channel: int
    instrument: str


@dataclass
class FMNoteOn(Event):
    channel: int
    note: str      # 'C','C#','D',... (see opn2._NOTE_OFFSETS)
    octave: int


@dataclass
class FMNoteOff(Event):
    channel: int


@dataclass
class PSGToneOn(Event):
    channel: int    # 0-2
    note: str
    octave: int
    volume: int = 0  # 0 = loudest, 15 = silent


@dataclass
class PSGToneOff(Event):
    channel: int


@dataclass
class PSGNoiseOn(Event):
    white: bool     # True = white noise, False = "periodic" noise
    rate: int       # 0,1,2 = fixed rates; 3 = synced to PSG tone channel 2
    volume: int = 0


@dataclass
class PSGNoiseOff(Event):
    pass


@dataclass
class End(Event):
    pass


_EVENT_TYPES = {
    "Wait": Wait,
    "FMInstrumentSelect": FMInstrumentSelect,
    "FMNoteOn": FMNoteOn,
    "FMNoteOff": FMNoteOff,
    "PSGToneOn": PSGToneOn,
    "PSGToneOff": PSGToneOff,
    "PSGNoiseOn": PSGNoiseOn,
    "PSGNoiseOff": PSGNoiseOff,
    "End": End,
}


def events_to_json(events: List[Event]) -> list:
    return [e.to_dict() for e in events]


def events_from_json(data: list) -> List[Event]:
    return [Event.from_dict(d) for d in data]
