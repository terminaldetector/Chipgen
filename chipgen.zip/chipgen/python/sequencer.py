"""
sequencer.py — turns a List[Event] into final mixed stereo audio by
driving the YM2612 and SN76489 emulators in parallel, each at its own
native sample rate, then resampling both to a common target rate and
summing.

This module is the "player" half of the DefleMask-for-neural-networks
idea: instruments.py + events.py define what a model can say, this file
is what makes it audible.
"""

import numpy as np
from scipy.signal import resample

import opn2
import sn76489
import events as events_mod
from instruments import BANK as INSTRUMENT_BANK


class Sequencer:
    def __init__(self, ticks_per_second: float = 192.0, target_rate: int = 44100):
        self.ticks_per_second = ticks_per_second
        self.target_rate = target_rate

    def render(self, event_list) -> np.ndarray:
        seconds_per_tick = 1.0 / self.ticks_per_second

        ym = opn2.YM2612()
        psg = sn76489.SN76489()

        fm_chunks, psg_chunks = [], []
        fm_pending, psg_pending = 0.0, 0.0

        for ev in event_list:
            if isinstance(ev, events_mod.Wait):
                dt = ev.ticks * seconds_per_tick
                fm_pending += dt * opn2.NATIVE_RATE
                psg_pending += dt * sn76489.NATIVE_RATE
                continue
            if isinstance(ev, events_mod.End):
                break

            n_fm = int(fm_pending)
            if n_fm > 0:
                fm_chunks.append(ym.render(n_fm))
                fm_pending -= n_fm
            n_psg = int(psg_pending)
            if n_psg > 0:
                psg_chunks.append(psg.render(n_psg))
                psg_pending -= n_psg

            self._apply(ev, ym, psg)

        n_fm = int(round(fm_pending))
        if n_fm > 0:
            fm_chunks.append(ym.render(n_fm))
        n_psg = int(round(psg_pending))
        if n_psg > 0:
            psg_chunks.append(psg.render(n_psg))

        fm_audio = (np.concatenate(fm_chunks, axis=0) if fm_chunks
                    else np.zeros((0, 2), dtype=np.float32))
        psg_audio = (np.concatenate(psg_chunks, axis=0) if psg_chunks
                     else np.zeros((0,), dtype=np.float32))

        ym.close()
        psg.close()

        return self._mix(fm_audio, psg_audio)

    @staticmethod
    def _apply(ev, ym: "opn2.YM2612", psg: "sn76489.SN76489"):
        if isinstance(ev, events_mod.FMInstrumentSelect):
            ym.set_instrument(ev.channel, INSTRUMENT_BANK[ev.instrument])
        elif isinstance(ev, events_mod.FMNoteOn):
            ym.note_on(ev.channel, ev.note, ev.octave)
        elif isinstance(ev, events_mod.FMNoteOff):
            ym.note_off(ev.channel)
        elif isinstance(ev, events_mod.PSGToneOn):
            psg.tone_on(ev.channel, ev.note, ev.octave, ev.volume)
        elif isinstance(ev, events_mod.PSGToneOff):
            psg.tone_off(ev.channel)
        elif isinstance(ev, events_mod.PSGNoiseOn):
            psg.noise_on(ev.white, ev.rate, ev.volume)
        elif isinstance(ev, events_mod.PSGNoiseOff):
            psg.noise_off()
        else:
            raise ValueError(f"unknown event: {ev!r}")

    def _mix(self, fm_audio: np.ndarray, psg_audio: np.ndarray) -> np.ndarray:
        fm_rs = self._resample_to_target(fm_audio, opn2.NATIVE_RATE)
        psg_mono = self._resample_to_target(psg_audio, sn76489.NATIVE_RATE)

        n = max(len(fm_rs), len(psg_mono))
        out = np.zeros((n, 2), dtype=np.float32)
        if len(fm_rs):
            out[:len(fm_rs)] += fm_rs
        if len(psg_mono):
            out[:len(psg_mono), 0] += psg_mono
            out[:len(psg_mono), 1] += psg_mono

        peak = float(np.max(np.abs(out))) if out.size else 0.0
        if peak > 1.0:
            out = out / peak * 0.98
        return out

    def _resample_to_target(self, audio: np.ndarray, orig_rate: float) -> np.ndarray:
        if len(audio) == 0:
            return audio
        n_out = max(1, round(len(audio) * self.target_rate / orig_rate))
        return resample(audio, n_out, axis=0).astype(np.float32)
