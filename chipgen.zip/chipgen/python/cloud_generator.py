"""
cloud_generator.py — same contract as demo_generator.py (returns
List[Event]), but the events come from a CLOUD model instead of a local
rule-based stub or a locally-hosted network. Proves the "any neural
network" claim isn't limited to in-process/local models: this is a
synchronous network call, the Sequencer doesn't know or care.

Uses the Anthropic API here as the concrete example (this project already
runs next to Claude), but the pattern is identical for any provider:
build a prompt describing events.py's vocabulary, demand JSON-only output,
parse, validate, done. Swap `_call_model()` for OpenAI/Gemini/whatever —
nothing else in this file, or in sequencer.py, changes.

Requires: pip install anthropic --break-system-packages
          export ANTHROPIC_API_KEY=...
"""

import os
import json
import re
from typing import List

from events import Event, events_from_json

INSTRUMENT_NAMES = ("bass", "distorted_lead", "bell_pluck", "jazz_chord_pad")
NOTE_NAMES = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

SYSTEM_PROMPT = """You are composing a short chiptune pattern for a Sega Genesis \
generative engine (real YM2612 FM + SN76489 PSG emulation, not a synthesizer \
imitating one). You do not control raw synthesis parameters directly — you \
output a sequence of high-level events that a real chip emulator executes \
exactly as written.

Output ONLY a JSON array. No prose, no markdown code fences, nothing before \
or after the array.

Event types (every object needs "type" plus the listed fields):

  {{"type": "Wait", "ticks": <int>}}
    Advances the sequence clock. There are {ticks_per_second} ticks per second.

  {{"type": "FMInstrumentSelect", "channel": <0-5>, "instrument": <name>}}
    instrument must be exactly one of: {instruments}

  {{"type": "FMNoteOn", "channel": <0-5>, "note": <name>, "octave": <int>}}
  {{"type": "FMNoteOff", "channel": <0-5>}}
    note must be exactly one of: {notes}  (octave 4 = middle, A4 = 440 Hz)

  {{"type": "PSGToneOn", "channel": <0-2>, "note": <name>, "octave": <int>, "volume": <0-15>}}
  {{"type": "PSGToneOff", "channel": <0-2>}}
    volume: 0 = loudest, 15 = silent

  {{"type": "PSGNoiseOn", "white": <bool>, "rate": <0-3>, "volume": <0-15>}}
  {{"type": "PSGNoiseOff"}}

  {{"type": "End"}}

Rules:
- Sequence must end with {{"type": "End"}}.
- FM channels 0-5 are independent FM voices. PSG channels 0-2 are square
  waves; noise is a shared 4th PSG voice (PSGNoiseOn/Off, no channel field).
- Turn a note off (or explicitly intend overlap) before retriggering the
  same channel.
- Stay under {max_events} events total.
- Assign an FMInstrumentSelect to a channel before its first FMNoteOn.
"""


def build_user_prompt(style: str, bars: int, bpm: int) -> str:
    return (f"Style brief: {style}\n"
            f"Length: {bars} bars at {bpm} BPM.\n"
            f"Output the JSON array now.")


def _call_model(system: str, user: str, model: str = "claude-sonnet-4-6") -> str:
    """The only function you'd swap for a different provider. Must return
    the raw text response."""
    import anthropic
    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env
    resp = client.messages.create(
        model=model,
        max_tokens=4000,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    return "".join(block.text for block in resp.content if block.type == "text")


def _extract_json_array(text: str) -> list:
    text = text.strip()
    # strip ```json ... ``` or ``` ... ``` fences if the model added them anyway
    fence = re.match(r"^```(?:json)?\s*(.*?)\s*```$", text, re.DOTALL)
    if fence:
        text = fence.group(1).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    start, end = text.find("["), text.rfind("]")
    if start != -1 and end != -1 and end > start:
        return json.loads(text[start:end + 1])
    raise ValueError(f"could not find a JSON array in model output:\n{text[:500]}")


def parse_and_validate(raw_json: list) -> List[Event]:
    events = []
    for i, d in enumerate(raw_json):
        if "type" not in d:
            raise ValueError(f"event #{i} missing 'type': {d}")
        try:
            events.append(Event.from_dict(d))
        except (KeyError, TypeError) as e:
            raise ValueError(f"event #{i} ({d}) failed to parse: {e}") from e
    if not events or not isinstance(events[-1], type(events_from_json([{"type": "End"}])[0])):
        events.append(events_from_json([{"type": "End"}])[0])
    return events


def generate_pattern_cloud(style: str = "dark digital fusion hardcore, Genesis FM",
                            bars: int = 4, bpm: int = 172,
                            ticks_per_second: float = 192.0,
                            model: str = "claude-sonnet-4-6") -> List[Event]:
    system = SYSTEM_PROMPT.format(
        ticks_per_second=ticks_per_second,
        instruments=", ".join(INSTRUMENT_NAMES),
        notes=", ".join(NOTE_NAMES),
        max_events=600,
    )
    user = build_user_prompt(style, bars, bpm)
    raw_text = _call_model(system, user, model=model)
    raw_json = _extract_json_array(raw_text)
    return parse_and_validate(raw_json)


if __name__ == "__main__":
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("Set ANTHROPIC_API_KEY first. Example without a real call:\n")
        mock_response = json.dumps([
            {"type": "FMInstrumentSelect", "channel": 0, "instrument": "bass"},
            {"type": "FMNoteOn", "channel": 0, "note": "A", "octave": 2},
            {"type": "Wait", "ticks": 24},
            {"type": "FMNoteOff", "channel": 0},
            {"type": "End"},
        ])
        print("model would return, e.g.:", mock_response)
        events = parse_and_validate(_extract_json_array(mock_response))
        print(f"parsed OK -> {len(events)} events:", events)
    else:
        events = generate_pattern_cloud()
        print(f"got {len(events)} events from the cloud model")
        from sequencer import Sequencer
        audio = Sequencer().render(events)
        from scipy.io import wavfile
        import numpy as np
        pcm16 = (np.clip(audio, -1, 1) * 32767).astype(np.int16)
        wavfile.write("../output/cloud_demo.wav", 44100, pcm16)
        print("wrote ../output/cloud_demo.wav")
