"""
instruments.py — a small bank of YM2612 FM patches, in the spirit of the
Contra: Hard Corps / Genesis "techno-metal" sound discussed earlier:
distorted FM lead, punchy bass, bell/pluck arp voice, jazz-funk chord pad.

A generative model selects instruments BY NAME/ID rather than programming
raw operator physics per note — same division of labour as a DefleMask
instrument bank referenced from pattern data.
"""

from opn2 import Operator, FMInstrument

BASS = FMInstrument(
    algorithm=0, feedback=5,
    operators=[
        Operator(detune=0, multiple=1, total_level=28, attack_rate=31,
                  decay_rate=8, sustain_rate=2, release_rate=8, sustain_level=3),
        Operator(detune=0, multiple=2, total_level=30, attack_rate=31,
                  decay_rate=10, sustain_rate=2, release_rate=8, sustain_level=4),
        Operator(detune=0, multiple=1, total_level=22, attack_rate=31,
                  decay_rate=6, sustain_rate=2, release_rate=8, sustain_level=3),
        Operator(detune=0, multiple=1, total_level=6, attack_rate=31,
                  decay_rate=5, sustain_rate=2, release_rate=9, sustain_level=2),
    ],
)

DISTORTED_LEAD = FMInstrument(
    algorithm=0, feedback=7,  # heavy self-feedback on op1 -> gritty/"guitar" edge
    operators=[
        Operator(detune=3, multiple=1, total_level=32, attack_rate=31,
                  decay_rate=4, sustain_rate=1, release_rate=7, sustain_level=4),
        Operator(detune=1, multiple=1, total_level=30, attack_rate=31,
                  decay_rate=6, sustain_rate=1, release_rate=7, sustain_level=4),
        Operator(detune=2, multiple=1, total_level=26, attack_rate=31,
                  decay_rate=5, sustain_rate=1, release_rate=7, sustain_level=3),
        Operator(detune=0, multiple=1, total_level=2, attack_rate=31,
                  decay_rate=3, sustain_rate=2, release_rate=6, sustain_level=1),
    ],
)

BELL_PLUCK = FMInstrument(
    algorithm=4, feedback=2,  # two independent 2-op pairs -> clean partials
    operators=[
        Operator(detune=0, multiple=1, total_level=4, attack_rate=31,
                  decay_rate=14, sustain_rate=8, release_rate=10, sustain_level=8),
        Operator(detune=0, multiple=7, total_level=20, attack_rate=31,
                  decay_rate=18, sustain_rate=10, release_rate=12, sustain_level=10),
        Operator(detune=0, multiple=1, total_level=6, attack_rate=31,
                  decay_rate=12, sustain_rate=6, release_rate=10, sustain_level=7),
        Operator(detune=0, multiple=3, total_level=16, attack_rate=31,
                  decay_rate=16, sustain_rate=8, release_rate=11, sustain_level=9),
    ],
)

JAZZ_CHORD_PAD = FMInstrument(
    algorithm=6, feedback=1,  # multiple carriers -> softer, more "additive" chord tone
    operators=[
        Operator(detune=0, multiple=1, total_level=14, attack_rate=18,
                  decay_rate=4, sustain_rate=1, release_rate=6, sustain_level=3),
        Operator(detune=1, multiple=2, total_level=18, attack_rate=16,
                  decay_rate=4, sustain_rate=1, release_rate=6, sustain_level=3),
        Operator(detune=6, multiple=1, total_level=16, attack_rate=17,
                  decay_rate=4, sustain_rate=1, release_rate=6, sustain_level=3),
        Operator(detune=2, multiple=3, total_level=20, attack_rate=15,
                  decay_rate=5, sustain_rate=1, release_rate=6, sustain_level=4),
    ],
)

BANK = {
    "bass": BASS,
    "distorted_lead": DISTORTED_LEAD,
    "bell_pluck": BELL_PLUCK,
    "jazz_chord_pad": JAZZ_CHORD_PAD,
}
