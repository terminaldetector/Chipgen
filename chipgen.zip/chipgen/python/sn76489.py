"""
sn76489.py — Python control layer for the Sega PSG (SN76489) core.

Native rate = chip_clock / 16 (the chip's internal working rate; each
channel's counter decrements once per tick at this rate). For NTSC:
3,579,545 / 16 = 223,721.5625 Hz.
"""

import ctypes
import os
import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_LIB_PATH = os.path.join(_HERE, "..", "core", "libpsg.so")

NTSC_PSG_CLOCK = 3_579_545
PAL_PSG_CLOCK = 3_546_893
NATIVE_RATE = NTSC_PSG_CLOCK / 16  # ~223721.5625 Hz

from opn2 import _NOTE_OFFSETS  # reuse the same note-name table


def note_to_freq(note: str, octave: int) -> float:
    semitones = _NOTE_OFFSETS[note] + (octave - 4) * 12
    return 440.0 * (2.0 ** (semitones / 12.0))


def freq_to_tone_n(freq: float, clock: float = NTSC_PSG_CLOCK) -> int:
    """freq -> 10-bit tone register value N (freq = clock / (32*N))."""
    n = round(clock / (32.0 * freq))
    return max(1, min(1023, n))


class _Lib:
    _lib = None

    @classmethod
    def get(cls):
        if cls._lib is None:
            lib = ctypes.CDLL(_LIB_PATH)
            lib.psg_new.restype = ctypes.c_void_p
            lib.psg_new.argtypes = []
            lib.psg_free.argtypes = [ctypes.c_void_p]
            lib.psg_reset.argtypes = [ctypes.c_void_p]
            lib.psg_write.argtypes = [ctypes.c_void_p, ctypes.c_ubyte]
            lib.psg_render.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                        ctypes.POINTER(ctypes.c_short)]
            cls._lib = lib
        return cls._lib


class SN76489:
    """Sega PSG: 3 square/tone channels (0-2) + 1 noise channel (3)."""

    def __init__(self):
        self._lib = _Lib.get()
        self._chip = self._lib.psg_new()

    def close(self):
        if self._chip:
            self._lib.psg_free(self._chip)
            self._chip = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def write(self, byte: int):
        self._lib.psg_write(self._chip, byte & 0xFF)

    # -- tone channels (0, 1, 2) ------------------------------------------------
    def tone_on(self, channel: int, note: str, octave: int, volume: int = 0,
                clock: float = NTSC_PSG_CLOCK):
        assert 0 <= channel <= 2
        n = freq_to_tone_n(note_to_freq(note, octave), clock)
        self.write(0x80 | (channel << 5) | (0 << 4) | (n & 0xF))
        self.write((n >> 4) & 0x3F)
        self.set_volume(channel, volume)

    def set_volume(self, channel: int, volume: int):
        """volume: 0 = loudest, 15 = silent."""
        assert 0 <= channel <= 3
        self.write(0x80 | (channel << 5) | (1 << 4) | (volume & 0xF))

    def tone_off(self, channel: int):
        self.set_volume(channel, 15)

    # -- noise channel (3) --------------------------------------------------------
    NOISE_RATE_LOW, NOISE_RATE_MED, NOISE_RATE_HIGH, NOISE_RATE_TONE2 = 0, 1, 2, 3

    def noise_on(self, white: bool, rate: int, volume: int = 0):
        mode_bit = 0x04 if white else 0x00
        data = mode_bit | (rate & 0x03)
        self.write(0x80 | (3 << 5) | (0 << 4) | data)
        self.set_volume(3, volume)

    def noise_off(self):
        self.set_volume(3, 15)

    # -- rendering ----------------------------------------------------------------
    def render(self, n_samples: int) -> np.ndarray:
        """Render n_samples of native-rate (~223721.56 Hz) mono audio.
        Returns float32 array in range [-1, 1]."""
        buf = (ctypes.c_short * n_samples)()
        self._lib.psg_render(self._chip, n_samples, buf)
        arr = np.frombuffer(buf, dtype=np.int16).astype(np.float32) / 32768.0
        return arr
