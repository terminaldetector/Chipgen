from typing import List
from events import Event
from cloud_generator import generate_pattern_cloud
from .base import Generator


class CloudGenerator(Generator):
    """Synchronous call to a cloud LLM (see cloud_generator.py, currently
    wired to the Anthropic API in _call_model()). Swapping providers means
    editing that one function — this class, the registry entry, and
    everything downstream (Sequencer) stay untouched."""

    def __init__(self, model: str = "claude-sonnet-4-6"):
        self.model = model

    def generate(self, style: str, bars: int = 4, bpm: int = 172,
                 ticks_per_second: float = 192.0, **kwargs) -> List[Event]:
        return generate_pattern_cloud(style=style, bars=bars, bpm=bpm,
                                       ticks_per_second=ticks_per_second,
                                       model=self.model)
