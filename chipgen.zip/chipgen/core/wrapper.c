/*
 * wrapper.c — thin render/control layer on top of Nuked-OPN2 (ym3438.c/.h)
 *
 * Exposes a small, ctypes-friendly C API:
 *   opn2_new / opn2_free
 *   opn2_write(port, data)
 *   opn2_render(n_samples, out_i16_stereo)  -> fills native-rate audio
 *
 * Native output rate = chip_clock / 6 / 24 (see README for derivation).
 * For NTSC Genesis (chip clock 7670453.57 Hz) that is ~319,602/6 ... see
 * python/opn2.py for the exact constant used.
 */
#include <stdlib.h>
#include <string.h>
#include "ym3438.h"

typedef struct {
    ym3438_t chip;
} OPN2Handle;

OPN2Handle *opn2_new(void) {
    OPN2Handle *h = (OPN2Handle *)malloc(sizeof(OPN2Handle));
    if (!h) return NULL;
    memset(h, 0, sizeof(OPN2Handle));
    OPN2_SetChipType(ym3438_mode_ym2612);
    OPN2_Reset(&h->chip);
    return h;
}

void opn2_free(OPN2Handle *h) {
    free(h);
}

void opn2_reset(OPN2Handle *h) {
    OPN2_Reset(&h->chip);
}

/* port: 0 = address bank 0, 1 = data bank 0, 2 = address bank 1, 3 = data bank 1
 *
 * The real chip (and this cycle-accurate model) sets an internal busy flag
 * for ~32 internal clocks after any write; a write issued while busy is
 * dropped. We settle past that window on every call so callers never have
 * to think about bus timing themselves. */
void opn2_write(OPN2Handle *h, unsigned int port, unsigned char data) {
    Bit16s dummy[2];
    int i;
    OPN2_Write(&h->chip, port, data);
    for (i = 0; i < 40; i++) {
        OPN2_Clock(&h->chip, dummy);
    }
}

/*
 * Render n_samples of native-rate interleaved 16-bit stereo audio into out.
 * out must be pre-allocated with space for n_samples * 2 shorts.
 *
 * Each output sample requires 24 internal clocks (6 channels * 4 operator
 * slots, round-robin FM pipeline) — the chip's mol/mor pins are a
 * sample-and-hold that only produces a "fresh" value once per 24-slot pass,
 * so we clock 24 times and keep the value from the final sub-clock.
 */
void opn2_render(OPN2Handle *h, int n_samples, short *out) {
    int i, j;
    Bit16s buffer[2];
    for (i = 0; i < n_samples; i++) {
        for (j = 0; j < 24; j++) {
            OPN2_Clock(&h->chip, buffer);
        }
        /* mol/mor are signed 9-bit; scale to 16-bit range (shift by 7)
           and clamp defensively. */
        long l = ((long)buffer[0]) << 7;
        long r = ((long)buffer[1]) << 7;
        if (l > 32767) l = 32767;
        if (l < -32768) l = -32768;
        if (r > 32767) r = 32767;
        if (r < -32768) r = -32768;
        out[i * 2]     = (short)l;
        out[i * 2 + 1] = (short)r;
    }
}
