import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "python"))

import numpy as np
from scipy.io import wavfile

from sequencer import Sequencer
from demo_generator import generate_pattern

def main():
    seq = Sequencer(ticks_per_second=192.0, target_rate=44100)
    events = generate_pattern(ticks_per_second=seq.ticks_per_second, bars=4)
    print(f"generated {len(events)} events")

    audio = seq.render(events)
    print(f"rendered {len(audio)} samples ({len(audio)/seq.target_rate:.2f}s) "
          f"peak={np.max(np.abs(audio)):.3f} rms={np.sqrt(np.mean(audio**2)):.4f}")

    out_path = os.path.join(os.path.dirname(__file__), "..", "output", "demo.wav")
    pcm16 = np.clip(audio, -1.0, 1.0)
    pcm16 = (pcm16 * 32767).astype(np.int16)
    wavfile.write(out_path, seq.target_rate, pcm16)
    print(f"wrote {out_path}")

if __name__ == "__main__":
    main()
